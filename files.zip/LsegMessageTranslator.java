package com.example.infrastructure.lseg;

import com.example.domain.model.MarketData;
import com.example.infrastructure.lseg.model.LsegResponse;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.Map;

/**
 * Anti-Corruption Layer (ACL) that translates LSEG TR-JSON2 response fields
 * into domain MarketData value objects.
 *
 * LSEG field names (TRDPRC_1, HIGH_1, etc.) are isolated here and never leak
 * into the domain model. If LSEG changes field names, only this class changes.
 */
@Component
public class LsegMessageTranslator {

    private static final Logger log = LoggerFactory.getLogger(LsegMessageTranslator.class);

    // LSEG field name constants
    private static final String FIELD_TRADE_PRICE = "TRDPRC_1";
    private static final String FIELD_HIGH = "HIGH_1";
    private static final String FIELD_LOW = "LOW_1";
    private static final String FIELD_OPEN = "OPEN_PRC";
    private static final String FIELD_CLOSE = "HST_CLOSE";
    private static final String FIELD_BID = "BID";
    private static final String FIELD_ASK = "ASK";
    private static final String FIELD_TRADE_DATE = "TRADE_DATE";

    /**
     * Translates an LSEG MarketPrice Refresh response into a domain MarketData value object.
     *
     * @param response the LSEG response containing Fields map
     * @return the translated MarketData domain object
     */
    public MarketData translate(LsegResponse response) {
        Map<String, Object> fields = response.fields();
        if (fields == null || fields.isEmpty()) {
            log.warn("LSEG response for ID {} has no fields", response.id());
            return null;
        }

        return new MarketData(
                toBigDecimal(fields.get(FIELD_TRADE_PRICE)),
                toBigDecimal(fields.get(FIELD_HIGH)),
                toBigDecimal(fields.get(FIELD_LOW)),
                toBigDecimal(fields.get(FIELD_OPEN)),
                toBigDecimal(fields.get(FIELD_CLOSE)),
                toBigDecimal(fields.get(FIELD_BID)),
                toBigDecimal(fields.get(FIELD_ASK)),
                toLocalDate(fields.get(FIELD_TRADE_DATE)),
                LocalDateTime.now() // Last traded time — LSEG doesn't always provide exact timestamp
        );
    }

    private BigDecimal toBigDecimal(Object value) {
        if (value == null) {
            return null;
        }
        try {
            return new BigDecimal(value.toString());
        } catch (NumberFormatException e) {
            log.warn("Could not parse BigDecimal from value: {}", value);
            return null;
        }
    }

    private LocalDate toLocalDate(Object value) {
        if (value == null) {
            return null;
        }
        try {
            return LocalDate.parse(value.toString(), DateTimeFormatter.ISO_LOCAL_DATE);
        } catch (Exception e) {
            log.warn("Could not parse LocalDate from value: {}", value);
            return null;
        }
    }
}
