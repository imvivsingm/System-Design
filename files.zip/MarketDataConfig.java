package com.example.config;

import com.example.domain.model.MarketData;
import com.example.domain.model.MarketDataRequest;
import com.github.benmanes.caffeine.cache.Cache;
import com.github.benmanes.caffeine.cache.Caffeine;
import org.springframework.boot.context.properties.EnableConfigurationProperties;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.web.socket.client.WebSocketClient;
import org.springframework.web.socket.client.standard.StandardWebSocketClient;

import java.util.concurrent.TimeUnit;

/**
 * Spring configuration for market data components.
 * Creates Caffeine cache and WebSocket client beans.
 */
@Configuration
@EnableConfigurationProperties(MarketDataProperties.class)
public class MarketDataConfig {

    @Bean
    public Cache<MarketDataRequest, MarketData> marketDataCache(MarketDataProperties properties) {
        return Caffeine.newBuilder()
                .expireAfterWrite(properties.cache().ttlSeconds(), TimeUnit.SECONDS)
                .maximumSize(properties.cache().maxSize())
                .recordStats()
                .build();
    }

    @Bean
    public WebSocketClient webSocketClient() {
        return new StandardWebSocketClient();
    }
}
