package com.example.infrastructure.lseg;

import com.example.config.MarketDataProperties;
import com.example.domain.model.MarketData;
import com.example.domain.model.MarketDataRequest;
import com.example.domain.port.MarketDataProvider;
import com.example.infrastructure.lseg.model.LsegMarketPriceRequest;
import com.example.infrastructure.lseg.model.LsegResponse;
import com.example.shared.constants.MarketDataConstants;
import com.example.shared.exception.LsegConnectionException;
import com.example.shared.exception.MarketDataUnavailableException;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;

import jakarta.annotation.PostConstruct;

import java.util.concurrent.CompletableFuture;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.atomic.AtomicInteger;

/**
 * Infrastructure adapter implementing the MarketDataProvider domain port.
 * Translates domain requests into LSEG TR-JSON2 subscribe messages,
 * sends them via WebSocketConnectionManager, and correlates responses
 * back using the LSEG request ID.
 *
 * All LSEG-specific concerns are encapsulated here.
 */
@Component
public class LsegMarketDataAdapter implements MarketDataProvider {

    private static final Logger log = LoggerFactory.getLogger(LsegMarketDataAdapter.class);

    private final WebSocketConnectionManager connectionManager;
    private final LsegMessageTranslator translator;
    private final ObjectMapper objectMapper;
    private final MarketDataProperties properties;

    /**
     * ID generator for LSEG requests. Starts at 2 because ID 1 is reserved for Login.
     */
    private final AtomicInteger requestIdGenerator = new AtomicInteger(MarketDataConstants.LOGIN_REQUEST_ID + 1);

    /**
     * Maps LSEG request ID → MarketDataRequest.
     * Used to route LSEG responses back to the correct CompletableFuture.
     */
    private final ConcurrentHashMap<Integer, PendingRequest> pendingRequests = new ConcurrentHashMap<>();

    public LsegMarketDataAdapter(WebSocketConnectionManager connectionManager,
                                 LsegMessageTranslator translator,
                                 ObjectMapper objectMapper,
                                 MarketDataProperties properties) {
        this.connectionManager = connectionManager;
        this.translator = translator;
        this.objectMapper = objectMapper;
        this.properties = properties;
    }

    @PostConstruct
    public void init() {
        // Register this adapter as the message handler for incoming LSEG messages
        connectionManager.setMessageHandler(this::handleLsegResponse);
    }

    /**
     * Sends a MarketPrice subscribe request to LSEG and returns a CompletableFuture
     * that will be completed when LSEG responds.
     *
     * @param request the market data request containing RIC and service
     * @return a CompletableFuture that completes with the translated MarketData
     */
    @Override
    public CompletableFuture<MarketData> fetch(MarketDataRequest request) {
        if (!connectionManager.isConnected()) {
            return CompletableFuture.failedFuture(
                    new LsegConnectionException("LSEG WebSocket is not connected"));
        }

        int requestId = requestIdGenerator.getAndIncrement();
        CompletableFuture<MarketData> future = new CompletableFuture<>();

        // Store pending request for response correlation
        pendingRequests.put(requestId, new PendingRequest(request, future));

        try {
            LsegMarketPriceRequest subscribeRequest = LsegMarketPriceRequest.of(
                    requestId, request.ric(), request.service());
            String json = objectMapper.writeValueAsString(subscribeRequest);
            connectionManager.send(json);
            log.debug("Sent MarketPrice subscribe: ID={}, RIC={}, Service={}",
                    requestId, request.ric(), request.service());
        } catch (JsonProcessingException e) {
            pendingRequests.remove(requestId);
            future.completeExceptionally(
                    new MarketDataUnavailableException("Failed to serialize subscribe request", e));
        } catch (LsegConnectionException e) {
            pendingRequests.remove(requestId);
            future.completeExceptionally(e);
        }

        return future;
    }

    /**
     * Handles incoming LSEG messages routed by WebSocketConnectionManager.
     * Correlates the response ID to the pending request and completes the future.
     */
    private void handleLsegResponse(LsegResponse response) {
        if (response.id() == null) {
            log.warn("Received LSEG response with no ID: Type={}", response.type());
            return;
        }

        PendingRequest pending = pendingRequests.remove(response.id());
        if (pending == null) {
            log.warn("Received LSEG response for unknown request ID: {}", response.id());
            return;
        }

        if (response.isMarketPriceRefresh()) {
            MarketData marketData = translator.translate(response);
            if (marketData != null) {
                pending.future().complete(marketData);
                log.debug("MarketPrice Refresh received: ID={}, RIC={}",
                        response.id(), pending.request().ric());
            } else {
                pending.future().completeExceptionally(
                        new MarketDataUnavailableException(
                                "Failed to translate LSEG response for RIC: " + pending.request().ric()));
            }
        } else if (response.isError()) {
            String errorText = response.state() != null ? response.state().text() : "Unknown error";
            pending.future().completeExceptionally(
                    new MarketDataUnavailableException(
                            "LSEG error for RIC " + pending.request().ric() + ": " + errorText));
            log.error("LSEG error for ID={}, RIC={}: {}",
                    response.id(), pending.request().ric(), errorText);
        } else {
            log.warn("Unexpected LSEG response type for ID={}: Type={}, Domain={}",
                    response.id(), response.type(), response.domain());
            pending.future().completeExceptionally(
                    new MarketDataUnavailableException(
                            "Unexpected response type from LSEG: " + response.type()));
        }
    }

    /**
     * Internal record to track pending requests for response correlation.
     */
    private record PendingRequest(
            MarketDataRequest request,
            CompletableFuture<MarketData> future
    ) {
    }
}
