package com.example.domain.model;

/**
 * Immutable Value Object representing a market data request.
 * Used as key for both Caffeine cache and in-flight ConcurrentHashMap.
 * 
 * Java record provides equals() and hashCode() based on all fields automatically,
 * which is critical for computeIfAbsent() to work correctly in the in-flight map.
 */
public record MarketDataRequest(
        String ric,
        String service
) {

    public MarketDataRequest {
        if (ric == null || ric.isBlank()) {
            throw new IllegalArgumentException("RIC must not be null or blank");
        }
        if (service == null || service.isBlank()) {
            throw new IllegalArgumentException("Service must not be null or blank");
        }
    }
}
