package com.example.infrastructure.lseg.model;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;

import java.util.Map;

/**
 * LSEG TR-JSON2 response message.
 * Generic structure that covers Login Refresh, MarketPrice Refresh, Status, and Ping messages.
 * LSEG-specific DTO — never leaks outside infrastructure layer.
 */
@JsonIgnoreProperties(ignoreUnknown = true)
public record LsegResponse(
        @JsonProperty("ID") Integer id,
        @JsonProperty("Type") String type,
        @JsonProperty("Domain") String domain,
        @JsonProperty("Key") Key key,
        @JsonProperty("State") State state,
        @JsonProperty("Fields") Map<String, Object> fields
) {

    @JsonIgnoreProperties(ignoreUnknown = true)
    public record Key(
            @JsonProperty("Name") String name,
            @JsonProperty("Service") String service
    ) {
    }

    @JsonIgnoreProperties(ignoreUnknown = true)
    public record State(
            @JsonProperty("Stream") String stream,
            @JsonProperty("Data") String data,
            @JsonProperty("Text") String text
    ) {
    }

    /**
     * Checks if this is a successful login response.
     */
    public boolean isLoginSuccess() {
        return "Login".equals(domain)
                && "Refresh".equals(type)
                && state != null
                && "Open".equals(state.stream())
                && "Ok".equals(state.data());
    }

    /**
     * Checks if this is a MarketPrice Refresh response.
     */
    public boolean isMarketPriceRefresh() {
        return "MarketPrice".equals(domain)
                && "Refresh".equals(type)
                && fields != null;
    }

    /**
     * Checks if this is a Ping message.
     */
    public boolean isPing() {
        return "Ping".equals(type);
    }

    /**
     * Checks if this is an error/status message.
     */
    public boolean isError() {
        return "Status".equals(type)
                && state != null
                && !"Ok".equals(state.data());
    }
}
