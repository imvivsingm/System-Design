package com.example.domain.service;

import com.example.domain.model.MarketData;
import com.example.domain.model.MarketDataRequest;
import com.example.domain.port.MarketDataProvider;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;

import java.util.concurrent.CompletableFuture;

/**
 * Domain service for market data operations.
 * Orchestrates fetch via the MarketDataProvider port interface.
 * Contains domain-level validation. No knowledge of caching, coalescing, or infrastructure.
 */
@Service
public class MarketDataDomainService {

    private static final Logger log = LoggerFactory.getLogger(MarketDataDomainService.class);

    private final MarketDataProvider marketDataProvider;

    public MarketDataDomainService(MarketDataProvider marketDataProvider) {
        this.marketDataProvider = marketDataProvider;
    }

    /**
     * Fetches market data for the given request via the provider port.
     *
     * @param request the market data request
     * @return a CompletableFuture that will be completed with market data
     */
    public CompletableFuture<MarketData> fetchMarketData(MarketDataRequest request) {
        log.debug("Fetching market data for RIC: {}, Service: {}", request.ric(), request.service());
        return marketDataProvider.fetch(request);
    }
}
