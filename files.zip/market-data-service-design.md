# Market Data Service — Design Document

**Service:** Security API — LSEG Elektron WebSocket (TR-JSON2) Market Data Integration  
**Date:** 2025-10-29  
**Status:** Draft

---

## 1. Problem Statement

The Security API currently returns dummy market data. We need to fetch real-time market data from LSEG via WebSocket. Each trader call to the Security API must return fresh market data **without** opening a new WebSocket connection per request.

---

## 2. Architecture Decision

**Pattern: Shared Singleton WebSocket + Caffeine Cache**

A single, application-scoped WebSocket connection to LSEG Elektron is maintained by the Infrastructure layer. It communicates using the **TR-JSON2** protocol (JSON over WebSocket). Market data received is stored in a **Caffeine cache** with TTL-based expiry and size-based eviction. All trader requests read from this cache — no per-request connections are opened.

**Protocol:** LSEG Elektron WebSocket API — TR-JSON2  
**Subscription:** Non-streaming snapshot (`"Streaming": false`) using RIC + Service (`IDN_RDF`)  
**Auth:** Credential-based Login message (username + applicationId)  
**Cache:** Caffeine (TTL + max size eviction)

### Why not per-request connections?
- LSEG rate-limits/connection-limits WebSocket clients
- Connection handshake + auth overhead per request (~100-300ms) is unacceptable
- Thousands of concurrent traders would exhaust server resources

### Why not Redis?
- Single-instance deployment (per requirements)
- Market data is ephemeral; process-local cache is sufficient
- No cross-service consumers for market data

---

## 3. Application Layers

```
┌──────────────────────────────────────────────────────────────┐
│                       Spring Boot App                         │
│                                                              │
│  ┌─ API Layer ─────────────────────────────────────────────┐ │
│  │  SecurityController (existing — unchanged)               │ │
│  └──────────────────────────┬──────────────────────────────┘ │
│                             │                                │
│  ┌─ Application Layer ──────┼──────────────────────────────┐ │
│  │                          ▼                               │ │
│  │  SecurityApplicationService (existing)                   │ │
│  │         │                                                │ │
│  │         │ delegates market data fetch                    │ │
│  │         ▼                                                │ │
│  │  MarketDataApplicationService (new)                      │ │
│  │         │  - Caffeine cache lookup                       │ │
│  │         │  - In-flight request coalescing                │ │
│  │         │  - Timeout handling                            │ │
│  └─────────┼────────────────────────────────────────────────┘ │
│            │                                                  │
│  ┌─ Domain Layer ──────────────────────────────────────────┐ │
│  │         ▼                                                │ │
│  │  MarketDataDomainService                                 │ │
│  │         │  - Orchestrates fetch via port interface        │ │
│  │         │  - Domain validation                           │ │
│  │         │                                                │ │
│  │  MarketData (Value Object)                               │ │
│  │  MarketDataRequest (Value Object — cache/in-flight key)  │ │
│  │  MarketDataProvider (Port Interface)                      │ │
│  └─────────┼────────────────────────────────────────────────┘ │
│            │ implements port                                   │
│  ┌─ Infrastructure Layer ──────────────────────────────────┐ │
│  │         ▼                                                │ │
│  │  LsegMarketDataAdapter (implements MarketDataProvider)   │ │
│  │         │                                                │ │
│  │         ├── WebSocketConnectionManager                   │ │
│  │         │      (singleton WS lifecycle, login, ping)     │ │
│  │         │                                                │ │
│  │         └── LsegMessageTranslator (ACL)                  │ │
│  │                (TRDPRC_1 → currentPrice)                 │ │
│  └─────────────────────────┬────────────────────────────────┘ │
│                            │ WSS                              │
│  ┌─ Shared Layer ──────────┼────────────────────────────────┐ │
│  │  Exceptions, constants, shared utilities                  │ │
│  └──────────────────────────────────────────────────────────┘ │
└────────────────────────────┼──────────────────────────────────┘
                             ▼
                    ┌──────────────┐
                    │  LSEG        │
                    │  Elektron    │
                    └──────────────┘
```

---

## 4. Component Responsibilities

### API Layer

#### 4.1 SecurityController
- Unchanged. POST endpoint receives security query request.
- Delegates to `SecurityApplicationService`.

### Application Layer

#### 4.2 SecurityApplicationService (existing)
- Fetches security details from DB via repository.
- Calls `MarketDataApplicationService.getMarketData(ric)` to enrich the response.
- Merges DB data + market data into the response DTO.
- Has **no knowledge** of LSEG, WebSocket, or TR-JSON2.

#### 4.3 MarketDataApplicationService (new)
- Entry point for all market data requests.
- Owns the **Caffeine cache** — checks cache first.
- Owns the **in-flight request map** for request coalescing (keyed by `MarketDataRequest` value object).
- On cache hit: returns cached `MarketData` directly.
- On cache miss: checks in-flight map → if absent, delegates to `MarketDataDomainService` → waits on `CompletableFuture` with configurable timeout.
- Handles timeout and fallback logic (stale data, null response).

### Domain Layer

#### 4.4 MarketDataDomainService
- Contains domain logic for fetching market data.
- Calls `MarketDataProvider` port interface to fetch from external source.
- Domain-level validation (e.g., RIC format validation if needed).
- No knowledge of caching, coalescing, or infrastructure.

#### 4.5 MarketDataProvider (Port Interface)
- Defined in domain layer.
- Contract: `MarketData fetch(MarketDataRequest request)`
- Implemented by `LsegMarketDataAdapter` in infrastructure layer.

#### 4.6 MarketData (Value Object)
- Immutable. Fields: `currentPrice`, `dayHighPrice`, `dayLowPrice`, `openPrice`, `lastClosePrice`, `tradeDate`, `bidPrice`, `askPrice`.
- Pure domain model — no LSEG field names.

#### 4.7 MarketDataRequest (Value Object — Cache & In-Flight Key)
- Immutable. Fields: `ric` (String), `service` (String, e.g. `IDN_RDF`).
- **Used as key** for both the Caffeine cache and the in-flight `ConcurrentHashMap`.
- Must implement `equals()` and `hashCode()` based on all fields.
- Using an object key instead of raw String future-proofs for scenarios where the same RIC could be requested from different services, or additional discriminators are added.

### Infrastructure Layer

#### 4.8 LsegMarketDataAdapter (implements MarketDataProvider)
- **Adapter** implementing the domain port.
- Translates `MarketDataRequest` into LSEG TR-JSON2 subscribe message.
- Sends via `WebSocketConnectionManager`, receives response, translates via `LsegMessageTranslator`.
- All LSEG-specific concerns are **encapsulated here**.

#### 4.9 WebSocketConnectionManager
- Manages the single persistent WebSocket connection to LSEG Elektron.
- Handles connection lifecycle: connect, login, ping/pong, reconnect.
- Routes incoming TR-JSON2 messages to the appropriate handler.
- Exposes `send(message)` for outbound requests.

#### 4.10 LsegMessageTranslator (ACL)
- Translates LSEG `Refresh` response fields into domain `MarketData` value objects.
- Maps `TRDPRC_1` → `currentPrice`, `HIGH_1` → `dayHighPrice`, etc.
- If LSEG changes field names or response format, **only this class changes**.

### Shared Layer

#### 4.11 Shared Concerns
- Custom exceptions: `MarketDataUnavailableException`, `LsegConnectionException`.
- Constants: field name mappings, default timeout values.
- Shared utilities if needed.

---

## 5. Cache & Coalescing Design

### 5.1 Caffeine Cache

```
Cache<MarketDataRequest, MarketData>
```

| Config | Value | Rationale |
|--------|-------|-----------|
| Key | `MarketDataRequest` (ric + service) | Object key; supports future multi-service lookups |
| Value | `MarketData` (value object) | Immutable, thread-safe |
| TTL | `expireAfterWrite(30, SECONDS)` — configurable | Prevents serving stale data |
| Max Size | `maximumSize(10_000)` — configurable | Bounded memory; LRU eviction |
| Stats | `recordStats()` enabled | Exposes hit/miss ratio via admin endpoint |

**Why Caffeine over ConcurrentHashMap:**
- Built-in TTL expiry — no custom scheduled cleanup
- Size-based eviction with LRU policy
- Built-in stats (hit rate, eviction count) for observability
- Thread-safe, high-performance concurrent access

### 5.2 In-Flight Request Map (Request Coalescing)

```
ConcurrentHashMap<MarketDataRequest, CompletableFuture<MarketData>>
```

| Aspect | Detail |
|--------|--------|
| Key | `MarketDataRequest` value object — requires correct `equals()` + `hashCode()` |
| Value | `CompletableFuture<MarketData>` — shared across all concurrent callers for the same request |
| Map operation | `computeIfAbsent(request, k -> triggerFetch(k))` — atomic, guarantees single LSEG call |
| Cleanup | `future.whenComplete()` removes entry from map (success or failure) |
| Timeout | Callers wait via `future.get(timeout)` — configurable |

### 5.3 ID Correlation (LSEG Response Routing)

| Map | Key | Value | Purpose |
|-----|-----|-------|---------|
| Caffeine cache | `MarketDataRequest` | `MarketData` | Cached results |
| In-flight | `MarketDataRequest` | `CompletableFuture<MarketData>` | Request coalescing |
| ID → Request | `Integer` (LSEG request ID) | `MarketDataRequest` | Route LSEG response to correct future |

- Each subscribe sent to LSEG carries a unique `ID` (generated by `AtomicInteger`).
- LSEG echoes the `ID` back in the response.
- `ConcurrentHashMap<Integer, MarketDataRequest>` maps the LSEG ID back to the `MarketDataRequest`, which is then used to look up and complete the corresponding `CompletableFuture` in the in-flight map.

---

## 6. Request Flow

### 6.1 Happy Path (Cache Hit)

```
Trader → Controller → SecurityAppService → DB (security details)
                                          → MarketDataAppService.getMarketData(ric)
                                              → Caffeine cache HIT → return MarketData
                    ← Response (security + marketData)
```

**Latency added:** ~0ms (in-memory lookup)

### 6.2 Cache Miss (Request Coalescing)

```
Trader 1 ─┐
Trader 2 ─┤  (all request AAPL.N concurrently)
  ...      ├→ MarketDataApplicationService.getMarketData("AAPL.N")
Trader N ─┘
                          │
                          ▼
                  ┌─── Caffeine MISS ───┐
                  │                      │
                  ▼                      │
        inFlightMap.computeIfAbsent()    │
             │            │              │
        (key absent)  (key exists)       │
             │            │              │
             ▼            ▼              │
      Create new     Return existing     │
   CompletableFuture  CompletableFuture  │
             │            │
             ▼            │
   MarketDataDomainService.fetch()
             │            │
             ▼            │
   MarketDataProvider.fetch()  (port → LsegAdapter)
             │            │
             ▼            │
   LsegAdapter sends ONE subscribe to LSEG
             │            │
             ▼            │
   LSEG responds (Refresh)│
             │            │
             ▼            │
   LsegMessageTranslator → MarketData
             │            │
             ▼            │
   future.complete()      │
   cache.put()            │
   inFlightMap.remove()   │
             │            │
             ▼            ▼
   All N traders receive the same MarketData
```

**Key behaviour:**

| Sequence | What happens |
|----------|-------------|
| Trader 1 requests AAPL.N | Cache miss → `computeIfAbsent` creates `CompletableFuture` → domain service → adapter → LSEG subscribe |
| Traders 2–N (before LSEG responds) | Cache miss → `computeIfAbsent` finds existing future → all wait (no duplicate subscribe) |
| LSEG responds | Future completes → all N callers unblock → Caffeine cache populated → future removed |
| Trader N+1 (after response) | Caffeine cache hit → served directly |

---

## 7. LSEG TR-JSON2 Protocol Details

**Login Message (sent once after WebSocket connect):**
```json
{
  "ID": 1,
  "Domain": "Login",
  "Key": {
    "Name": {
      "Type": "Name",
      "Data": "<username>"
    },
    "Elements": {
      "ApplicationId": "<app-id>",
      "Position": "<host-ip>"
    }
  }
}
```

**Login Response:** LSEG responds with a `Refresh` message (`"Type": "Refresh"`, `"Domain": "Login"`). Check `"State": {"Stream": "Open", "Data": "Ok"}` for success.

**Market Price Subscribe (non-streaming snapshot):**
```json
{
  "ID": 2,
  "Domain": "MarketPrice",
  "Key": {
    "Name": "<RIC>",
    "Service": "IDN_RDF"
  },
  "Streaming": false
}
```

**Market Price Response:**
```json
{
  "ID": 2,
  "Type": "Refresh",
  "Domain": "MarketPrice",
  "Key": { "Name": "AAPL.N", "Service": "IDN_RDF" },
  "Fields": {
    "TRDPRC_1": 142.35,
    "HIGH_1": 144.00,
    "LOW_1": 139.50,
    "OPEN_PRC": 140.00,
    "HST_CLOSE": 141.20,
    "TRADE_DATE": "2025-10-29",
    "BID": 142.30,
    "ASK": 142.40
  }
}
```

**Field Mapping (LsegMessageTranslator — ACL):**

| LSEG Field | MarketData Field |
|------------|-----------------|
| `TRDPRC_1` | `currentPrice` |
| `HIGH_1` | `dayHighPrice` |
| `LOW_1` | `dayLowPrice` |
| `OPEN_PRC` | `openPrice` |
| `HST_CLOSE` | `lastClosePrice` |
| `TRADE_DATE` | `tradeDate` |
| `BID` | `bidPrice` |
| `ASK` | `askPrice` |

**Ping/Pong:** LSEG sends `{"Type": "Ping"}` → respond with `{"Type": "Pong"}`.

**Key Protocol Notes:**
- `"Streaming": false` — LSEG sends one `Refresh` and closes the item stream. No unsubscribe needed.
- `ID` is client-assigned. LSEG echoes it back for correlation.
- `ID: 1` reserved for Login. Market data requests use `ID: 2+` via `AtomicInteger`.

---

## 8. WebSocket Connection Lifecycle

### 8.1 Startup
1. Application starts → `WebSocketConnectionManager` initialized (`@PostConstruct` or `SmartLifecycle`).
2. Opens WebSocket connection to LSEG Elektron endpoint.
3. Sends **Login message** with username, applicationId, and position (from config).
4. Waits for Login `Refresh` response with `"State": {"Stream": "Open", "Data": "Ok"}`.
5. Connection is ready — `LsegMarketDataAdapter` can now send subscribe requests.

### 8.2 Reconnection Strategy

| Scenario | Action |
|----------|--------|
| Connection drops | Exponential backoff reconnect (1s, 2s, 4s, ... max 60s) → re-login after reconnect |
| Login rejected | Log error, alert, do not retry (likely config issue) |
| LSEG maintenance | Backoff + circuit breaker opens after N failures |

### 8.3 Heartbeat (Ping/Pong)
- LSEG sends `{"Type": "Ping"}` periodically.
- `WebSocketConnectionManager` must respond with `{"Type": "Pong"}` immediately.
- If no Ping received within expected interval → connection may be dead → trigger reconnect.

### 8.4 Shutdown
- `@PreDestroy`: Close WebSocket connection gracefully.
- No explicit unsubscribe needed — `"Streaming": false` means item streams auto-close.
- Complete any pending in-flight futures exceptionally so blocked callers unblock.

---

## 9. Resilience & Error Handling

| Failure Mode | Handling |
|--------------|----------|
| WebSocket disconnected | Return stale cache (Caffeine may still hold expired-but-present entries if configured) + header flag `X-MarketData-Stale: true` |
| Cache miss + WS down | Return response without market data; populate `marketData: null` with error reason |
| LSEG timeout on subscribe | `CompletableFuture` times out → all coalesced callers get timeout → in-flight entry removed → next request retries |
| LSEG returns error for RIC | Complete future exceptionally → callers get error → don't cache errors |
| Poison message from LSEG | Log + discard; don't crash the listener |

**Circuit Breaker (optional):** Wrap LSEG subscribe calls with Resilience4j circuit breaker to avoid thundering-herd retries.

---

## 10. Thread Model

| Component | Threading |
|-----------|-----------|
| WebSocket listener | Single Netty/reactor thread (inbound messages) |
| Caffeine cache reads | Lock-free concurrent reads |
| Caffeine cache writes | Thread-safe internally |
| Cache-miss fetch | Caller thread blocks on `CompletableFuture` (bounded by timeout) |
| Request coalescing | `computeIfAbsent` is atomic; multiple callers share one future — no extra threads |

No custom thread pools needed. Spring WebSocket client handles I/O threads internally.

---

## 11. Configuration (application.yml)

```yaml
market-data:
  lseg:
    websocket-url: wss://ads-hostname:15443/WebSocket
    username: ${LSEG_USERNAME}
    application-id: "256"
    position: "127.0.0.1"
    service: IDN_RDF
    ping-timeout-seconds: 60
    reconnect-max-backoff-seconds: 60
  cache:
    ttl-seconds: 30
    max-size: 10000
  subscribe:
    timeout-seconds: 5
```

---

## 12. Package Structure

```
com.example
│
├── api                                        # API Layer
│   └── SecurityController                     # Existing — unchanged
│
├── application                                # Application Layer
│   ├── SecurityApplicationService             # Existing — calls MarketDataApplicationService
│   └── MarketDataApplicationService           # NEW — cache + coalescing + timeout
│
├── domain                                     # Domain Layer
│   ├── service
│   │   └── MarketDataDomainService            # NEW — domain orchestration + validation
│   ├── model
│   │   ├── MarketData                         # Value Object (immutable)
│   │   └── MarketDataRequest                  # Value Object (ric + service) — cache key
│   └── port
│       └── MarketDataProvider                 # Port Interface — implemented by infra
│
├── infrastructure                             # Infrastructure Layer
│   ├── persistence
│   │   └── SecurityRepository                 # Existing
│   └── lseg                                   # NEW — LSEG adapter (ACL boundary)
│       ├── LsegMarketDataAdapter              # Implements MarketDataProvider port
│       ├── WebSocketConnectionManager         # Singleton WS lifecycle
│       ├── LsegMessageTranslator              # ACL: TRDPRC_1 → currentPrice
│       └── model                              # LSEG-specific DTOs (never leak outside)
│           ├── LsegLoginRequest
│           ├── LsegMarketPriceRequest
│           └── LsegResponse
│
├── shared                                     # Shared Layer
│   ├── exception
│   │   ├── MarketDataUnavailableException
│   │   └── LsegConnectionException
│   └── constants
│       └── MarketDataConstants
│
└── config
    └── MarketDataConfig                       # Caffeine bean, WS config, properties binding
```

**Layer Dependency Rule:**

```
API → Application → Domain ← Infrastructure
                      ↑
                    Shared (accessible by all layers)
```

- Domain depends on **nothing** (pure).
- Application depends on Domain.
- Infrastructure **implements** Domain ports.
- API depends on Application.
- Shared is cross-cutting (exceptions, constants).

---

## 13. Key Design Decisions

| # | Decision | Rationale |
|---|----------|-----------|
| 1 | Singleton WebSocket connection | Avoids per-request connection overhead; respects LSEG connection limits |
| 2 | Caffeine cache | Built-in TTL, LRU eviction, stats — no custom cleanup logic needed |
| 3 | `MarketDataRequest` as object key | Future-proofs for multi-service or multi-discriminator lookups; cleaner than string concatenation |
| 4 | Request coalescing via in-flight future map | Prevents thundering herd; N concurrent requests for same RIC+service = 1 LSEG subscribe |
| 5 | Stale-data fallback on WS failure | Availability over consistency — slightly stale price is better than no response |
| 6 | `MarketDataDomainService` separate from `ApplicationService` | Domain logic (validation, orchestration) stays in domain layer; application layer handles cross-cutting (cache, timeout, coalescing) |
| 7 | Port & Adapter (`MarketDataProvider`) | Domain depends on abstraction. Swap LSEG for Bloomberg by writing a new adapter — no domain/application changes |
| 8 | Anti-Corruption Layer (`LsegMessageTranslator`) | LSEG field names (`TRDPRC_1`) and protocol quirks never leak into domain model |
| 9 | `MarketData` as Value Object | Immutable, no identity, thread-safe by design |
| 10 | `"Streaming": false` | Simplifies lifecycle — no unsubscribe, no continuous update handling |

---

## 14. Future Considerations

- **Horizontal scaling:** If multiple instances are deployed, each holds its own WS connection and Caffeine cache. Consider Redis only if cross-instance consistency is needed.
- **Pre-warming:** Subscribe to top-N traded securities at startup to reduce cache-miss latency.
- **Streaming mode:** If requirements evolve to push real-time updates to traders, add SSE/WebSocket endpoint on the API side.
