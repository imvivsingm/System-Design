package com.example.infrastructure.lseg.model;

import com.fasterxml.jackson.annotation.JsonProperty;

import java.util.Map;

/**
 * LSEG TR-JSON2 Login request message.
 * LSEG-specific DTO — never leaks outside infrastructure layer.
 */
public record LsegLoginRequest(
        @JsonProperty("ID") int id,
        @JsonProperty("Domain") String domain,
        @JsonProperty("Key") Key key
) {

    public record Key(
            @JsonProperty("Name") Name name,
            @JsonProperty("Elements") Map<String, String> elements
    ) {
    }

    public record Name(
            @JsonProperty("Type") String type,
            @JsonProperty("Data") String data
    ) {
    }

    public static LsegLoginRequest of(String username, String applicationId, String position) {
        return new LsegLoginRequest(
                1,
                "Login",
                new Key(
                        new Name("Name", username),
                        Map.of(
                                "ApplicationId", applicationId,
                                "Position", position
                        )
                )
        );
    }
}
