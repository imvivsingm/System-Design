package com.example.infrastructure.lseg.model;

import com.fasterxml.jackson.annotation.JsonProperty;

/**
 * LSEG TR-JSON2 MarketPrice subscribe request message.
 * LSEG-specific DTO — never leaks outside infrastructure layer.
 */
public record LsegMarketPriceRequest(
        @JsonProperty("ID") int id,
        @JsonProperty("Domain") String domain,
        @JsonProperty("Key") Key key,
        @JsonProperty("Streaming") boolean streaming
) {

    public record Key(
            @JsonProperty("Name") String name,
            @JsonProperty("Service") String service
    ) {
    }

    public static LsegMarketPriceRequest of(int id, String ric, String service) {
        return new LsegMarketPriceRequest(
                id,
                "MarketPrice",
                new Key(ric, service),
                false  // Non-streaming snapshot
        );
    }
}
