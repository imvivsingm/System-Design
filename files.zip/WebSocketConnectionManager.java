package com.example.infrastructure.lseg;

import com.example.config.MarketDataProperties;
import com.example.infrastructure.lseg.model.LsegLoginRequest;
import com.example.infrastructure.lseg.model.LsegResponse;
import com.example.shared.exception.LsegConnectionException;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;
import org.springframework.web.socket.CloseStatus;
import org.springframework.web.socket.TextMessage;
import org.springframework.web.socket.WebSocketHttpHeaders;
import org.springframework.web.socket.WebSocketSession;
import org.springframework.web.socket.client.WebSocketClient;
import org.springframework.web.socket.handler.TextWebSocketHandler;

import jakarta.annotation.PostConstruct;
import jakarta.annotation.PreDestroy;

import java.io.IOException;
import java.net.URI;
import java.util.concurrent.CompletableFuture;
import java.util.concurrent.Executors;
import java.util.concurrent.ScheduledExecutorService;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.atomic.AtomicBoolean;
import java.util.concurrent.atomic.AtomicInteger;
import java.util.function.Consumer;

/**
 * Manages the single persistent WebSocket connection to LSEG Elektron.
 * Handles: connect, login, ping/pong, reconnect with exponential backoff.
 *
 * This is a singleton bean — all market data requests share this one connection.
 */
@Component
public class WebSocketConnectionManager extends TextWebSocketHandler {

    private static final Logger log = LoggerFactory.getLogger(WebSocketConnectionManager.class);

    private final WebSocketClient webSocketClient;
    private final MarketDataProperties properties;
    private final ObjectMapper objectMapper;
    private final ScheduledExecutorService scheduler = Executors.newSingleThreadScheduledExecutor();

    private volatile WebSocketSession session;
    private volatile boolean loggedIn = false;
    private final AtomicBoolean reconnecting = new AtomicBoolean(false);
    private final AtomicInteger backoffSeconds = new AtomicInteger(1);
    private final CompletableFuture<Void> loginFuture = new CompletableFuture<>();

    private Consumer<LsegResponse> messageHandler;

    public WebSocketConnectionManager(WebSocketClient webSocketClient,
                                      MarketDataProperties properties,
                                      ObjectMapper objectMapper) {
        this.webSocketClient = webSocketClient;
        this.properties = properties;
        this.objectMapper = objectMapper;
    }

    /**
     * Registers a handler for incoming LSEG messages (MarketPrice Refresh, Status, etc.).
     * Called by LsegMarketDataAdapter during initialization.
     */
    public void setMessageHandler(Consumer<LsegResponse> handler) {
        this.messageHandler = handler;
    }

    @PostConstruct
    public void connect() {
        doConnect();
    }

    @PreDestroy
    public void disconnect() {
        scheduler.shutdownNow();
        if (session != null && session.isOpen()) {
            try {
                session.close(CloseStatus.NORMAL);
                log.info("LSEG WebSocket connection closed gracefully");
            } catch (IOException e) {
                log.warn("Error closing LSEG WebSocket connection", e);
            }
        }
    }

    /**
     * Sends a text message over the WebSocket connection.
     *
     * @param message the JSON message to send
     * @throws LsegConnectionException if the connection is not available
     */
    public void send(String message) {
        if (session == null || !session.isOpen()) {
            throw new LsegConnectionException("LSEG WebSocket connection is not available");
        }
        try {
            session.sendMessage(new TextMessage(message));
            log.debug("Sent to LSEG: {}", message);
        } catch (IOException e) {
            throw new LsegConnectionException("Failed to send message to LSEG", e);
        }
    }

    /**
     * Returns a future that completes when login is successful.
     * Callers can wait on this before sending subscribe requests.
     */
    public CompletableFuture<Void> awaitLogin() {
        return loginFuture;
    }

    /**
     * Checks if the connection is active and logged in.
     */
    public boolean isConnected() {
        return session != null && session.isOpen() && loggedIn;
    }

    // --- WebSocket handler callbacks ---

    @Override
    public void afterConnectionEstablished(WebSocketSession session) {
        this.session = session;
        this.backoffSeconds.set(1);
        this.reconnecting.set(false);
        log.info("LSEG WebSocket connection established");
        sendLogin();
    }

    @Override
    protected void handleTextMessage(WebSocketSession session, TextMessage message) {
        String payload = message.getPayload();
        log.debug("Received from LSEG: {}", payload);

        try {
            // LSEG sends responses as JSON arrays
            LsegResponse[] responses = objectMapper.readValue(payload, LsegResponse[].class);
            for (LsegResponse response : responses) {
                handleResponse(response);
            }
        } catch (JsonProcessingException e) {
            log.error("Failed to parse LSEG message: {}", payload, e);
        }
    }

    @Override
    public void handleTransportError(WebSocketSession session, Throwable exception) {
        log.error("LSEG WebSocket transport error", exception);
        scheduleReconnect();
    }

    @Override
    public void afterConnectionClosed(WebSocketSession session, CloseStatus status) {
        log.warn("LSEG WebSocket connection closed: {}", status);
        this.loggedIn = false;
        this.session = null;
        scheduleReconnect();
    }

    // --- Internal methods ---

    private void doConnect() {
        try {
            String url = properties.lseg().websocketUrl();
            log.info("Connecting to LSEG WebSocket: {}", url);
            webSocketClient.execute(this, new WebSocketHttpHeaders(), URI.create(url));
        } catch (Exception e) {
            log.error("Failed to connect to LSEG WebSocket", e);
            scheduleReconnect();
        }
    }

    private void sendLogin() {
        try {
            LsegLoginRequest loginRequest = LsegLoginRequest.of(
                    properties.lseg().username(),
                    properties.lseg().applicationId(),
                    properties.lseg().position()
            );
            String json = objectMapper.writeValueAsString(loginRequest);
            send(json);
            log.info("LSEG login request sent for user: {}", properties.lseg().username());
        } catch (JsonProcessingException e) {
            log.error("Failed to serialize LSEG login request", e);
        }
    }

    private void handleResponse(LsegResponse response) {
        if (response.isPing()) {
            handlePing();
            return;
        }

        if (response.isLoginSuccess()) {
            this.loggedIn = true;
            loginFuture.complete(null);
            log.info("LSEG login successful");
            return;
        }

        // Login failure
        if ("Login".equals(response.domain()) && response.isError()) {
            String errorText = response.state() != null ? response.state().text() : "Unknown";
            log.error("LSEG login failed: {}", errorText);
            loginFuture.completeExceptionally(new LsegConnectionException("Login failed: " + errorText));
            return;
        }

        // Delegate all other messages (MarketPrice Refresh, Status, etc.) to the handler
        if (messageHandler != null) {
            messageHandler.accept(response);
        } else {
            log.warn("No message handler registered for LSEG response: ID={}, Type={}", response.id(), response.type());
        }
    }

    private void handlePing() {
        try {
            String pong = objectMapper.writeValueAsString(new PongMessage("Pong"));
            send(pong);
            log.debug("Sent Pong to LSEG");
        } catch (JsonProcessingException e) {
            log.error("Failed to send Pong to LSEG", e);
        }
    }

    private void scheduleReconnect() {
        if (reconnecting.compareAndSet(false, true)) {
            int delay = backoffSeconds.getAndUpdate(current ->
                    Math.min(current * 2, properties.lseg().reconnectMaxBackoffSeconds()));
            log.info("Scheduling LSEG reconnect in {} seconds", delay);
            scheduler.schedule(() -> {
                reconnecting.set(false);
                doConnect();
            }, delay, TimeUnit.SECONDS);
        }
    }

    // Simple Pong message for Jackson serialization
    private record PongMessage(String Type) {
    }
}
