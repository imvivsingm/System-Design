package com.example.application;

import com.example.config.MarketDataProperties;
import com.example.domain.model.MarketData;
import com.example.domain.model.MarketDataRequest;
import com.example.domain.service.MarketDataDomainService;
import com.example.shared.exception.MarketDataUnavailableException;
import com.github.benmanes.caffeine.cache.Cache;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;

import java.util.concurrent.CompletableFuture;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.TimeoutException;

/**
 * Application service for market data.
 * Owns the Caffeine cache and in-flight request map for request coalescing.
 *
 * Flow:
 * 1. Check Caffeine cache → if hit, return immediately.
 * 2. Check in-flight map → if existing future found, wait on it (coalescing).
 * 3. If no in-flight request, create new CompletableFuture, delegate to domain service, wait.
 * 4. On response: populate cache, remove from in-flight map, return to all waiting callers.
 */
@Service
public class MarketDataApplicationService {

    private static final Logger log = LoggerFactory.getLogger(MarketDataApplicationService.class);

    private final MarketDataDomainService domainService;
    private final Cache<MarketDataRequest, MarketData> cache;
    private final MarketDataProperties properties;

    /**
     * In-flight request map for request coalescing.
     * Key: MarketDataRequest (value object with equals/hashCode on ric + service)
     * Value: CompletableFuture shared across all concurrent callers for the same request
     *
     * computeIfAbsent is atomic — guarantees only one LSEG subscribe per unique request.
     */
    private final ConcurrentHashMap<MarketDataRequest, CompletableFuture<MarketData>> inFlightRequests =
            new ConcurrentHashMap<>();

    public MarketDataApplicationService(MarketDataDomainService domainService,
                                        Cache<MarketDataRequest, MarketData> cache,
                                        MarketDataProperties properties) {
        this.domainService = domainService;
        this.cache = cache;
        this.properties = properties;
    }

    /**
     * Gets market data for the given RIC.
     * Uses Caffeine cache and request coalescing to minimize LSEG calls.
     *
     * @param ric the Reuters Instrument Code (e.g., "AAPL.N")
     * @return the market data, or null if unavailable
     */
    public MarketData getMarketData(String ric) {
        MarketDataRequest request = new MarketDataRequest(ric, properties.lseg().service());

        // 1. Check Caffeine cache
        MarketData cached = cache.getIfPresent(request);
        if (cached != null) {
            log.debug("Cache HIT for RIC: {}", ric);
            return cached;
        }

        log.debug("Cache MISS for RIC: {}", ric);

        // 2. Request coalescing via in-flight map
        //    computeIfAbsent is atomic: first caller creates the future and triggers fetch,
        //    subsequent callers get the same future and wait on it.
        CompletableFuture<MarketData> future = inFlightRequests.computeIfAbsent(request, this::triggerFetch);

        // 3. Wait for result with timeout
        try {
            MarketData result = future.get(properties.subscribe().timeoutSeconds(), TimeUnit.SECONDS);

            // 4. Populate cache on success
            if (result != null) {
                cache.put(request, result);
            }

            return result;

        } catch (TimeoutException e) {
            log.warn("Timeout waiting for market data: RIC={}", ric);
            return null;
        } catch (ExecutionException e) {
            log.error("Error fetching market data for RIC: {}", ric, e.getCause());
            return null;
        } catch (InterruptedException e) {
            Thread.currentThread().interrupt();
            log.warn("Interrupted while waiting for market data: RIC={}", ric);
            return null;
        }
    }

    /**
     * Triggers the actual fetch via the domain service.
     * Called only once per unique MarketDataRequest due to computeIfAbsent atomicity.
     *
     * The returned CompletableFuture is shared across all concurrent callers.
     * Cleanup (removing from in-flight map) happens in whenComplete — regardless of success or failure.
     */
    private CompletableFuture<MarketData> triggerFetch(MarketDataRequest request) {
        log.info("Triggering LSEG fetch for RIC: {}, Service: {}", request.ric(), request.service());

        CompletableFuture<MarketData> future = domainService.fetchMarketData(request);

        // Cleanup: remove from in-flight map when done (success or failure)
        future.whenComplete((result, throwable) -> {
            inFlightRequests.remove(request);
            if (throwable != null) {
                log.error("LSEG fetch failed for RIC: {}", request.ric(), throwable);
            } else {
                log.debug("LSEG fetch completed for RIC: {}", request.ric());
            }
        });

        return future;
    }
}
