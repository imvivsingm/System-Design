package com.example.domain.port;

import com.example.domain.model.MarketData;
import com.example.domain.model.MarketDataRequest;

import java.util.concurrent.CompletableFuture;

/**
 * Outbound port interface for fetching market data from an external provider.
 * Defined in the domain layer — implemented by infrastructure adapters (e.g., LsegMarketDataAdapter).
 * 
 * Returns CompletableFuture to support async WebSocket-based communication
 * where the response arrives on a different thread than the request.
 */
public interface MarketDataProvider {

    /**
     * Sends a market data request to the external provider.
     * The returned CompletableFuture will be completed when the provider responds.
     *
     * @param request the market data request containing RIC and service
     * @return a CompletableFuture that will be completed with the market data
     */
    CompletableFuture<MarketData> fetch(MarketDataRequest request);
}
