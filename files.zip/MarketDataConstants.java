package com.example.shared.constants;

/**
 * Constants shared across layers for market data operations.
 */
public final class MarketDataConstants {

    private MarketDataConstants() {
        // Utility class
    }

    /** LSEG Login domain */
    public static final String DOMAIN_LOGIN = "Login";

    /** LSEG MarketPrice domain */
    public static final String DOMAIN_MARKET_PRICE = "MarketPrice";

    /** LSEG message types */
    public static final String TYPE_REFRESH = "Refresh";
    public static final String TYPE_STATUS = "Status";
    public static final String TYPE_PING = "Ping";
    public static final String TYPE_PONG = "Pong";

    /** Reserved LSEG request ID for login */
    public static final int LOGIN_REQUEST_ID = 1;

    /** LSEG response state values */
    public static final String STATE_STREAM_OPEN = "Open";
    public static final String STATE_DATA_OK = "Ok";
}
