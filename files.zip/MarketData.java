package com.example.domain.model;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.time.LocalDateTime;

/**
 * Immutable Value Object representing market data for a security.
 * Pure domain model — no LSEG field names or infrastructure concerns.
 */
public record MarketData(
        BigDecimal currentPrice,
        BigDecimal dayHighPrice,
        BigDecimal dayLowPrice,
        BigDecimal openPrice,
        BigDecimal lastClosePrice,
        BigDecimal bidPrice,
        BigDecimal askPrice,
        LocalDate tradeDate,
        LocalDateTime lastTradedTime
) {
}
