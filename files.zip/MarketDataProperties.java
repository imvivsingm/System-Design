package com.example.config;

import org.springframework.boot.context.properties.ConfigurationProperties;

/**
 * Configuration properties for market data, bound from application.yml.
 */
@ConfigurationProperties(prefix = "market-data")
public record MarketDataProperties(
        LsegProperties lseg,
        CacheProperties cache,
        SubscribeProperties subscribe
) {

    public record LsegProperties(
            String websocketUrl,
            String username,
            String applicationId,
            String position,
            String service,
            int pingTimeoutSeconds,
            int reconnectMaxBackoffSeconds
    ) {
    }

    public record CacheProperties(
            int ttlSeconds,
            int maxSize
    ) {
    }

    public record SubscribeProperties(
            int timeoutSeconds
    ) {
    }
}
