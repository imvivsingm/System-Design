package com.example.shared.exception;

/**
 * Thrown when there is a connection issue with the LSEG WebSocket.
 */
public class LsegConnectionException extends RuntimeException {

    public LsegConnectionException(String message) {
        super(message);
    }

    public LsegConnectionException(String message, Throwable cause) {
        super(message, cause);
    }
}
